package db;

import java.util.List;
import java.util.Scanner;
import dao.AlunoDao;
import modelo.Aluno;

public class TesteOperacoes {
	
	public static void main(String[] args) {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext()) {
            context.scan("seu.pacote.de.projeto");
            context.refresh();
            
            AlunoDao alunoDAO = context.getBean(AlunoDao.class);
            
            Scanner scanner = new Scanner(System.in);
            
            
            Aluno aluno = new Aluno();
            System.out.print("Nome do aluno: ");
            aluno.setNome(scanner.nextLine());
            System.out.println("CPF do aluno: ");
            aluno.setCpf(scanner.nextLine());
            System.out.println("Data de Nascimento: ");
            aluno.setDataNascimento(null);
            System.out.println("Email do aluno: ");
            aluno.setEmail(scanner.nextLine());
            System.out.println("Endereco do aluno: ");
            aluno.setEndereco(scanner.nextLine());
            System.out.println("Naturalidade do aluno");
            aluno.setNaturalidade(scanner.nextLine());
           
            
            alunoDAO.salvarAluno(aluno);
            
            
            List<Aluno> alunos = alunoDAO.listarAlunos();
            System.out.println("Alunos cadastrados:");
            for (Aluno a : alunos) {
                System.out.println(a.getNome());
            }
            
            // Listando alunos por inicial do nome
            System.out.print("Digite a letra inicial do nome: ");
            String letraInicial = scanner.nextLine();
            List<Aluno> alunosPorInicialDoNome = alunoDAO.listarAlunosPorInicialDoNome(letraInicial);
            System.out.println("Alunos com inicial do nome " + letraInicial + ":");
            for (Aluno a : alunosPorInicialDoNome) {
                System.out.println(a.getNome());
            }
            
            // Atualizando um aluno
            System.out.print("Digite o ID do aluno a ser atualizado: ");
            Long alunoId = Long.parseLong(scanner.nextLine());
            Aluno alunoAtualizado = alunoDAO.buscarAlunoPorId(alunoId);
            System.out.print("Novo nome do aluno: ");
            alunoAtualizado.setNome(scanner.nextLine());
            // Atualize os demais atributos do aluno
            
            alunoDAO.atualizarAluno(alunoAtualizado);
        }
    }
}
