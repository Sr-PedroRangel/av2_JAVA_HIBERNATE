package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import modelo.Aluno;

@Repository
public class AlunoDao {
    @PersistenceContext
    private EntityManager entityManager;
    
    public void salvarAluno(Aluno aluno) {
        entityManager.persist(aluno);
    }
    
    public List<Aluno> listarAlunos() {
        return entityManager.createQuery("SELECT a FROM Aluno a", Aluno.class).getResultList();
    }
    
    public List<Aluno> listarAlunosPorInicialDoNome(String letraInicial) {
        return entityManager.createQuery("SELECT a FROM Aluno a WHERE a.nome LIKE :letraInicial%", Aluno.class)
            .setParameter("letraInicial", letraInicial)
            .getResultList();
    }
    
    public void atualizarAluno(Aluno aluno) {
        entityManager.merge(aluno);
    }
     
}
    
    
